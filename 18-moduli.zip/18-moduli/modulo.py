#
# Funzioni e moduli in Python
# Esempio riepilogativo: un modulo di funzioni per la contabilita
#
# Disponibile su devACADEMY.it
#

ivaCatA=22
ivaCatB=4
ivaCatC=12

def addizionaIVA(prezzo, categoria):
	if categoria=='B':
		aliquota=ivaCatB
	elif categoria=='C':
		aliquota=ivaCatC
	else:
		aliquota=ivaCatA
	return prezzo*(100+aliquota)/100

def impostaIVA(aliquota, categoria):
	global ivaCatA, ivaCatB, ivaCatC
	if categoria=='A':
		ivaCatA=aliquota
	elif categoria=='B':
		ivaCatB=aliquota
	elif categoria=='C':
		ivaCatC=aliquota

def totaleImporto(carrello):
	totale=0
	for articolo in carrello:
		# articolo = ('descrizione prodotto', prezzo, cat)
		descrizione=articolo[0]
		prezzo=articolo[1]
		categoria=articolo[2]
		prezzoConIVA=addizionaIVA(prezzo, categoria)
		totale+=prezzoConIVA
		print(f'{descrizione} - {prezzoConIVA}')
	print('\n==============================\n')
	print(f'Totale (IVA inclusa) - {totale} euro')