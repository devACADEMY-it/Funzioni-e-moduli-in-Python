#
# Funzioni e moduli in Python
# Esempio riepilogativo: un modulo di funzioni per la contabilita
#
# Disponibile su devACADEMY.it
#

from modulo import totaleImporto as calcola
from modulo import impostaIVA as cambia

carrello=[
('10 cod. 12345', 30, 'A'),
('4 cod. 58937', 6, 'A'),
('1 cod. 564333', 10, 'C'),
('4 cod. 977797', 2, 'A')
]

cambia(15,'C')

calcola(carrello)