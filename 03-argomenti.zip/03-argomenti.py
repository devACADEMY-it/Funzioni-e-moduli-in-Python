#
# Funzioni e moduli in Python
# Uso di argomenti
#
# Disponibile su devACADEMY.it
#

def saluto(tipo, nome):
	print(tipo+" "+nome)

# saluto("Alessia")
# saluto("Marco")
# saluto("Giovanni")

saluto("Buongiorno", "professoressa")
saluto("Salve", "amico")
saluto("Ciao", "Alessia")