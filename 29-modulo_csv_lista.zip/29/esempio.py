#
# Funzioni e moduli in Python
# Creazione di un modulo: da CSV a lista
#
# Disponibile su devACADEMY.it
#

import modulo as m
nome='dati.csv'
risultati=m.letturaCSV(nome)
print(risultati)