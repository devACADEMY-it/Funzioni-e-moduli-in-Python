#
# Funzioni e moduli in Python
# Creazione di un modulo: da CSV a lista
#
# Disponibile su devACADEMY.it
#

import csv

def letturaCSV(nome, separatore=';'):
	with open(nome) as f:
		csv_r=csv.reader(f, delimiter=separatore)
		return list(csv_r)