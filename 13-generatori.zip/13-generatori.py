#
# Funzioni e moduli in Python
# Definizione di generatori
#
# Disponibile su devACADEMY.it
#

def generatore():
	yield 10
	yield 20
	yield 30

#g=generatore()

#print(next(g))
#print(next(g))
#print(next(g))
#print(next(g))

#lista=list(generatore())
#print(lista)

for x in generatore():
	print(x)