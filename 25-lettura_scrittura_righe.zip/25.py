#
# Funzioni e moduli in Python
# Lettura e scrittura per righe
#
# Disponibile su devACADEMY.it
#

file='Infinito.txt'

with open(file, encoding='utf-8') as f:
	for riga in f.readlines():
		print(riga.strip())

print('\n===============================\n')


with open(file, encoding='utf-8') as f:
	riga=f.readline()
	cont=1
	while riga:
		print(f'(Riga {cont}) {riga.strip()}')
		riga=f.readline()
		cont+=1