#
# Funzioni e moduli in Python
# Esempio riepilogativo: filtro di dati mediante pattern
#
# Disponibile su devACADEMY.it
#

import re
carrello=[
'10 cod 123456 3.51 A',
'4 cod 583454 63.2 A',
'1 cod 564333 7.23 C',
'3 cod 977797 2.54 D'
]

r=re.compile(r'([\w\s]+) (\d+\.\d{1,2}) (A|B|C)')
for articolo in carrello:
	m=r.match(articolo)
	if m:
		print(f'OK {articolo}')
	else:
		print(f'KO {articolo}')