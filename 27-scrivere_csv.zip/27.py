#
# Funzioni e moduli in Python
# Scrivere CSV
#
# Disponibile su devACADEMY.it
#

from random import choice, randrange
import csv

codici=['RM001','RM002','TO001','MI001']

with open('dati_random.csv', mode='w',newline='') as f:
	csv_writer=csv.writer(f, delimiter=',')
	csv_writer.writerow(['Codice','Importo'])
	for i in range(1,21):
		csv_writer.writerow([choice(codici), randrange(20,151)])