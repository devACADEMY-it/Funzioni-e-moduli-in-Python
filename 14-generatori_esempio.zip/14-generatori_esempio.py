#
# Funzioni e moduli in Python
# Esempio pratico: generatore di una tabellina "infinita"
#
# Disponibile su devACADEMY.it
#

def tabellina(fattore):
	ind=1
	while(True):
		yield ind*fattore
		ind+=1

t=tabellina(8)

print(next(t))
print(next(t))

print("inizio primo ciclo")
for x in range(1,12):
	print(next(t))

print("inizio secondo ciclo")
for x in range(1,12):
	print(next(t))

# list(tabellina(5))   ===>  MemoryError