#
# Funzioni e moduli in Python
# Restituzione di risultati
#
# Disponibile su devACADEMY.it
#

def operazioni(op1, op2):
	return op1+op2, op1-op2, op1*op2

# prodotto = moltiplica(7,6)
# print(prodotto)

somma, sottrazione, prodotto = operazioni(8,2)
print(somma)
print(sottrazione)
print(prodotto)