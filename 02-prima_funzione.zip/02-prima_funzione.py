#
# Funzioni e moduli in Python
# Definizione di funzioni
#
# Disponibile su devACADEMY.it
#

def saluto():
	# esecuzione della funzione
	print("Ciao a tutti")

print("*** invocazione n. 1")
saluto()

print("*** invocazione n. 2")
saluto()

print("*** invocazione n. 3")
saluto()