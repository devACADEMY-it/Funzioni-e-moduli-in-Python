#
# Funzioni e moduli in Python
# Leggere file
#
# Disponibile su devACADEMY.it
#

with open('Infinito.txt',encoding='utf-8') as f:
	print(f.read(50))