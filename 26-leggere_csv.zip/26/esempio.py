#
# Funzioni e moduli in Python
# Leggere CSV
#
# Disponibile su devACADEMY.it
#

import csv
with open('incassi.csv') as f:
	csv_r=csv.reader(f, delimiter=',')
	#for riga in csv_r:
	#	if riga[0]=='RM001':
	#		print(riga)
	print(list(csv_r))