#
# Funzioni e moduli in Python
# Visibilità delle variabili
#
# Disponibile su devACADEMY.it
#

iva=22

def prezzo_con_iva(prezzo):
	risultato=prezzo*(100+iva)/100
	return risultato

def modifica_iva(nuovo_valore):
	global iva
	iva=nuovo_valore

modifica_iva(15)
prezzo_ivato=prezzo_con_iva(100)
print(prezzo_ivato)