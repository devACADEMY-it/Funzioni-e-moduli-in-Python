#
# Funzioni e moduli in Python
# Creazione di un modulo: analisi della lista
#
# Disponibile su devACADEMY.it
#

import csv

def letturaCSV(nome, separatore=';'):
	with open(nome) as f:
		csv_r=csv.reader(f, delimiter=separatore)
		return list(csv_r)

def divisioneCodici(lista):
	from re import search
	pattern=r'^\d{4}$'
	dizionario={'codice':[], 'descrizione':[]}
	for el in lista:
		chiave='codice' if search(pattern, el[1]) else 'descrizione'
		dizionario[chiave].append(el)
	return dizionario