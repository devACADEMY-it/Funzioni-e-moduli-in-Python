#
# Funzioni e moduli in Python
# Creazione di un modulo: analisi della lista
#
# Disponibile su devACADEMY.it
#

import modulo as m
nome='dati.csv'
risultati=m.letturaCSV(nome)
dd=m.divisioneCodici(risultati)
print(dd)