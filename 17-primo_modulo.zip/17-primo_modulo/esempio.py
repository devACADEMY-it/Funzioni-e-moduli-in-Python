#
# Funzioni e moduli in Python
# Creare un proprio modulo
#
# Disponibile su devACADEMY.it
#

#import modulo
#modulo.saluto()
from modulo import saluto as ciao
ciao()