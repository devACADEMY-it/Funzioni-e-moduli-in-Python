#
# Funzioni e moduli in Python
# Creare un proprio modulo
#
# Disponibile su devACADEMY.it
#

def saluto():
	print('Ciao dal tuo nuovo modulo...')