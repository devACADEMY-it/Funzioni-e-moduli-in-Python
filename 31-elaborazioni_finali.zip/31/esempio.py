#
# Funzioni e moduli in Python
# Elaborazioni finali
#
# Disponibile su devACADEMY.it
#

import modulo as m
nome='dati.csv'
risultati=m.letturaCSV(nome)
dd=m.divisioneCodici(risultati)
m.salvaDizionario(dd, 'finale.csv', 'codice', 'descrizione')