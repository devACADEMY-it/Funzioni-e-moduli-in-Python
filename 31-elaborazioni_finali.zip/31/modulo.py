#
# Funzioni e moduli in Python
# Elaborazioni finali
#
# Disponibile su devACADEMY.it
#

import csv

def letturaCSV(nome, separatore=';'):
	with open(nome) as f:
		csv_r=csv.reader(f, delimiter=separatore)
		return list(csv_r)

def divisioneCodici(lista):
	from re import search
	pattern=r'^\d{4}$'
	dizionario={'codice':[], 'descrizione':[]}
	for el in lista:
		chiave='codice' if search(pattern, el[1]) else 'descrizione'
		dizionario[chiave].append(el)
	return dizionario

def salvaLista(nome, lista):
	with open(nome, mode='w', newline='') as csv_file:
		csv_writer=csv.writer(csv_file, delimiter=',')
		for l in lista:
			csv_writer.writerow(l)

def salvaDizionario(dizionario, nome, chiave1, chiave2):
	if chiave1 in dizionario:
		salvaLista(f'{chiave1}_{nome}', dizionario[chiave1])
	if chiave2 in dizionario:
		salvaLista(f'{chiave2}_{nome}', dizionario[chiave2])