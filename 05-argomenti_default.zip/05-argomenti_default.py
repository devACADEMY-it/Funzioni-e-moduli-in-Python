#
# Funzioni e moduli in Python
# Argomenti con nome e valore di default
#
# Disponibile su devACADEMY.it
#

def prezzo_con_iva(prezzo, iva=22):
	return prezzo*(100+iva)/100

def prezzo_con_iva_sconto(prezzo, iva=22, sconto=10):
	prezzo_ivato=prezzo*(100+iva)/100
	return prezzo_ivato*(100-sconto)/100

pi_sconto=prezzo_con_iva_sconto(100, sconto=20)
print(pi_sconto)

#pr1 = prezzo_con_iva(100)
#pr2 = prezzo_con_iva(100, 4)