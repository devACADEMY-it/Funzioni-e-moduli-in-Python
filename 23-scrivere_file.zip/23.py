#
# Funzioni e moduli in Python
# Scrivere file
#
# Disponibile su devACADEMY.it
#

with open('dati.txt', 'a') as f:
	f.write('Prima riga...\n')
	f.write('ulteriori elementi da salvare')